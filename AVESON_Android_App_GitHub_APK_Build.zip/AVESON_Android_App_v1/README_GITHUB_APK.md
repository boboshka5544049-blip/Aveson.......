# AVESON APK — GitHub orqali build qilish

1. Ushbu loyiha fayllarini GitHub repository'ga yuklang.
2. GitHub'da **Actions** bo'limini oching.
3. **Build AVESON APK** workflow'ini tanlang.
4. **Run workflow** tugmasini bosing.
5. Build tugagach, workflow sahifasining pastidan **Artifacts** → **aveson-debug-apk** ni yuklab oling.
6. ZIP ichidagi `app-debug.apk` faylini Android telefonga o'tkazing va o'rnating.

Workflow APK'ni avtomatik yaratadi. Repository'ni Private qilib qo'yish mumkin.
