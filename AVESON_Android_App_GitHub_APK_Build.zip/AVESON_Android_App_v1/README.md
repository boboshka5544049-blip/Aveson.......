# AVESON Android App v1

Native Android starter for AVESON. Futuristic dark/purple/blue UI with Artist and Admin demo entry points.

## What is included
- Native Android app project
- Login screen
- Artist Dashboard
- Admin Dashboard
- AVESON visual direction
- Ready structure for connecting the secure PostgreSQL backend

## Important
This is the Android application source project, not a production APK. The current environment does not have the Android SDK/Gradle toolchain installed, so an APK cannot be compiled here.

Next production connection:
1. Connect Login/Register to AVESON v4 API.
2. Connect real session authentication.
3. Connect PostgreSQL data.
4. Add audio/cover upload.
5. Add admin approval.
6. Add distribution and royalty APIs.
