package com.aveson.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.content.Context

class MainActivity : android.app.Activity() {
    private val bg = Color.rgb(7,8,18); private val panel = Color.rgb(17,20,38)
    private val purple = Color.rgb(139,92,246); private val blue = Color.rgb(56,189,248)
    private val white = Color.rgb(245,247,255); private val muted = Color.rgb(154,163,189)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }
    fun base(): LinearLayout { root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg); root.setPadding(28,38,28,20); return root }
    fun text(s:String,size:Float,color:Int=white):TextView { return TextView(this).apply{ text=s; textSize=size; setTextColor(color); setPadding(0,8,0,8) } }
    fun button(s:String, action:()->Unit):Button { return Button(this).apply{ text=s; textSize=15f; setTextColor(white); setOnClickListener{action()}; background=GradientDrawable().apply{cornerRadius=22f;setColor(purple)} } }
    fun card(title:String,value:String):LinearLayout { val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(20,16,20,16); l.background=GradientDrawable().apply{cornerRadius=24f;setColor(panel)}; l.addView(text(title,13f,muted)); l.addView(text(value,24f,white)); return l }

    private fun showLogin(){ val v=base(); v.gravity=Gravity.CENTER_VERTICAL; v.addView(text("AVESON",42f,purple)); v.addView(text("Your Music. Your Global Stage.",18f)); v.addView(text("Artist music business — one powerful app.",14f,muted));
        val email=EditText(this).apply{hint="Email";setTextColor(white);setHintTextColor(muted)}; val pass=EditText(this).apply{hint="Password";inputType=129;setTextColor(white);setHintTextColor(muted)}; v.addView(email,lp());v.addView(pass,lp()); v.addView(button("Sign In") { showDashboard(false) },lp()); v.addView(button("Demo Admin") { showDashboard(true) },lp()); v.addView(text("v1 • secure backend will be connected next",12f,muted)); setContentView(v) }
    private fun lp():LinearLayout.LayoutParams=LinearLayout.LayoutParams(-1,58).apply{setMargins(0,8,0,8)}
    private fun showDashboard(admin:Boolean){ val v=base(); val top=LinearLayout(this); top.orientation=LinearLayout.HORIZONTAL; top.addView(text(if(admin)"AVESON ADMIN" else "AVESON",28f,purple),LinearLayout.LayoutParams(0,70,1f)); top.addView(text(if(admin)"ADMIN" else "ARTIST",13f,blue));v.addView(top)
        v.addView(text(if(admin)"Control Center" else "Artist Dashboard",18f)); val grid=LinearLayout(this); grid.orientation=LinearLayout.VERTICAL; grid.addView(card("TOTAL STREAMS","128,540"),lp());grid.addView(card("EARNINGS","$1,284.60"),lp());grid.addView(card("ACTIVE RELEASES","12"),lp());grid.addView(card("TOP COUNTRY","Uzbekistan"),lp());v.addView(grid,LinearLayout.LayoutParams(-1,0,1f));
        val nav=LinearLayout(this);nav.orientation=LinearLayout.HORIZONTAL;nav.gravity=Gravity.CENTER; nav.addView(button("Dashboard"){showDashboard(admin)});nav.addView(button(if(admin)"Queue" else "Upload"){Toast.makeText(this,if(admin)"Release Queue" else "Upload Music",Toast.LENGTH_SHORT).show()});nav.addView(button("Profile"){Toast.makeText(this,"Profile",Toast.LENGTH_SHORT).show()});v.addView(nav);setContentView(v)}
}
